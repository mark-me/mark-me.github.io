prep_datasource_c <- function(do_processing){
  
  if(do_processing){
    # Load source data
    # Transform source data in data frame 'df_source_c'
    v_col_1 <- c(200:400)
    v_col_2 <- c(600:800)
    df_source_c <- data.frame(v_col_1, v_col_2)
    
    # Write dataframe 'df_source_c' to processed file
    write.fst(df_source_c, "source_c.fst", 100)
  } else {
    # Load previously processed data in a data frame 'df_source_c'
    df_source_c <- read.fst("source_c.fst")
  }
  # check if data frame 'df_source_c' exists, otherwise stop the script
  stopifnot(exists("df_source_c"))
  return(df_source_c)
}
