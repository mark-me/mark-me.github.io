library(fst)

source("prep_datasource_a.R")
source("prep_datasource_b.R")
source("prep_datasource_c.R")

prep_datasources <- function(do_processing){
  df_source_a <- prep_datasource_a(do_processing)
  df_source_b <- prep_datasource_b(do_processing)
  df_source_c <- prep_datasource_c(do_processing)
    
  if(do_processing){
    df_source_general <- cbind(df_source_a, col_gen = rep(1:4, 10))
    write.fst(df_source_general, "source_general.fst", 100)
  } else {
    # Load previously processed data in a data frame 'df'
    df_source_general <- read.fst("source_general.fst")
  }
  stopifnot(exists("df_source_general") )  # check if data frame 'df' exists, otherwise stop the script
  # return the data frame 'df' with processed data
  list_df <-
    list(df_source_a = df_source_a, 
         df_source_b = df_source_b, 
         df_source_c = df_source_c, 
         df_source_general = df_source_general)
  return(list_df)
}
