prep_datasource_a <- function(do_processing){
  
  if(do_processing){
    # Load source data
    # Transform source data in data frame 'df_source_a'
    v_col_1 <- c(1:40)
    v_col_2 <- c(1:40)
    df_source_a <- data.frame(v_col_1, v_col_2)
    
    # Write dataframe 'df_source_a' to processed file
    write.fst(df_source_a, "source_a.fst", 100)
  } else {
    # Load previously processed data in a data frame 'df_source_a'
    df_source_a <- read.fst("source_a.fst")
  }
  # check if data frame 'df_source_a' exists, otherwise stop the script
  stopifnot(exists("df_source_a"))
  return(df_source_a)
}
