setwd("/home/mark/Downloads/Dropbox/Werk/R Scripts/structuring-data-processing/")

do_processing <- FALSE
source("data-prep.R")

list2env(prep_datasources(do_processing) ,.GlobalEnv)