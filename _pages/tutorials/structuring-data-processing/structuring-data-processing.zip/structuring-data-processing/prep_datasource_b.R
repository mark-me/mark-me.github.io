prep_datasource_b <- function(do_processing){
  
  if(do_processing){
    # Load source data
    # Transform source data in data frame 'df_source_b'
    v_col_1 <- c(1:100)
    v_col_2 <- c(1:100)
    df_source_b <- data.frame(v_col_1, v_col_2)
    
    # Write dataframe 'df_source_b' to processed file
    write.fst(df_source_b, "source_b.fst", 100)
  } else {
    # Load previously processed data in a data frame 'df_source_b'
    df_source_b <- read.fst("source_b.fst")
  }
  # check if data frame 'df_source_b' exists, otherwise stop the script
  stopifnot(exists("df_source_b"))
  return(df_source_b)
}
